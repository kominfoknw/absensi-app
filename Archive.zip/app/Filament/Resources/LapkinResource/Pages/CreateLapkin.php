<?php

namespace App\Filament\Resources\LapkinResource\Pages;

use App\Filament\Resources\LapkinResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLapkin extends CreateRecord
{
    protected static string $resource = LapkinResource::class;
}
