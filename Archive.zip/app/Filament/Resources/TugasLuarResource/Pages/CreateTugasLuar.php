<?php

namespace App\Filament\Resources\TugasLuarResource\Pages;

use App\Filament\Resources\TugasLuarResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTugasLuar extends CreateRecord
{
    protected static string $resource = TugasLuarResource::class;
}
