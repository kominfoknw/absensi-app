<?php

namespace App\Filament\Resources\EvaluasiLapkinResource\Pages;

use App\Filament\Resources\EvaluasiLapkinResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateEvaluasiLapkin extends CreateRecord
{
    protected static string $resource = EvaluasiLapkinResource::class;
}
