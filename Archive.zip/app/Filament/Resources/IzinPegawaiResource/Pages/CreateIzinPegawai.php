<?php

namespace App\Filament\Resources\IzinPegawaiResource\Pages;

use App\Filament\Resources\IzinPegawaiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateIzinPegawai extends CreateRecord
{
    protected static string $resource = IzinPegawaiResource::class;
}
