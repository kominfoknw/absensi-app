<?php

namespace App\Filament\Resources\DataImportExportResource\Pages;

use App\Filament\Resources\DataImportExportResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataImportExport extends CreateRecord
{
    protected static string $resource = DataImportExportResource::class;
}
