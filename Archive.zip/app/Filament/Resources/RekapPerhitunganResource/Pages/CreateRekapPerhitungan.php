<?php

namespace App\Filament\Resources\RekapPerhitunganResource\Pages;

use App\Filament\Resources\RekapPerhitunganResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRekapPerhitungan extends CreateRecord
{
    protected static string $resource = RekapPerhitunganResource::class;
}
